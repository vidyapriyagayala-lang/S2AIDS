# FSAD Exam – Hibernate HQL Demo

**Package:** `com.klef.fsad.exam`  
**Database:** `fsadexam`

This mini project shows:

1. **Insert** a `Shipment` record using a persistent object.  
2. **Delete** a `Shipment` by **ID** using **HQL** with a **named parameter**.

## Project Structure
```
fsadexam-hql/
├─ pom.xml
├─ src/
│  └─ main/
│     ├─ java/
│     │  └─ com/klef/fsad/exam/
│     │     ├─ ClientDemo.java
│     │     ├─ HibernateUtil.java
│     │     └─ Shipment.java
│     └─ resources/
│        └─ hibernate.cfg.xml
└─ README.md
```

## Prerequisites
- **Java 8+**
- **Maven 3.6+**
- **MySQL 8+** running locally

> The DB name should be `fsadexam`. The configuration is in `src/main/resources/hibernate.cfg.xml`.

Update these properties if needed:
```xml
<property name="hibernate.connection.username">root</property>
<property name="hibernate.connection.password">password</property>
```

## How to Run
1. **Create DB (optional):** Not required because the URL contains `createDatabaseIfNotExist=true`.
2. **Build & Package (creates a runnable fat JAR):**
   ```bash
   mvn -q -DskipTests package
   ```
3. **Run:**
   ```bash
   java -jar target/fsadexam-hql-1.0-SNAPSHOT-shaded.jar
   ```
   - The program inserts one sample `Shipment`.
   - It then asks you to enter a `Shipment ID` to delete, and performs HQL delete using a **named parameter**.

## HQL Used
```java
Query<?> deleteQuery = session.createQuery("delete from Shipment where id = :sid");
deleteQuery.setParameter("sid", idToDelete);
int affected = deleteQuery.executeUpdate();
```

## What to Submit
1. Create a **GitHub repository** and push this project.
2. Submit the **repository link** (e.g., `https://github.com/<your-username>/fsadexam-hql`).

### Quick Steps to Push to GitHub
```bash
# from inside the fsadexam-hql folder
git init
git add .
git commit -m "FSAD Exam: Shipment insert + HQL delete demo"
# create an empty repo on GitHub named fsadexam-hql, then:
git branch -M main
git remote add origin https://github.com/<your-username>/fsadexam-hql.git
git push -u origin main
```

## Troubleshooting
- **Access denied for user 'root'@'localhost'** → Check username/password in `hibernate.cfg.xml`.
- **Driver not found** → Make sure Maven downloaded dependencies; run `mvn -U clean package`.
- **Table not created** → Ensure `hibernate.hbm2ddl.auto` is set to `update` (or `create` on first run).
- **Timezone errors** → The JDBC URL already includes `serverTimezone=UTC`.

Good luck! ✨