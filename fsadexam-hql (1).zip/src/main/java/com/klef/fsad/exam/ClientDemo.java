package com.klef.fsad.exam;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.time.LocalDate;
import java.util.Scanner;

public class ClientDemo {
    public static void main(String[] args) {
        // Open a session
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // I. Insert records using a persistent object
            Transaction tx = session.beginTransaction();

            Shipment shipment = new Shipment();
            shipment.setName("Sample Shipment");
            shipment.setDate(LocalDate.now());
            shipment.setStatus("CREATED");
            shipment.setDescription("Demo record inserted via persistent object");
            shipment.setTrackingNumber("TRK-0001");

            // Persist makes the entity managed (persistent) and schedules an INSERT
            session.persist(shipment);
            tx.commit();
            System.out.println("Inserted Shipment with ID: " + shipment.getId());

            // II. Delete a record based on the ID using HQL with a named parameter
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter a Shipment ID to delete: ");
            long idToDelete = sc.nextLong();

            Transaction tx2 = session.beginTransaction();
            Query<?> deleteQuery = session.createQuery("delete from Shipment where id = :sid");
            deleteQuery.setParameter("sid", idToDelete);
            int affected = deleteQuery.executeUpdate();
            tx2.commit();

            if (affected > 0) {
                System.out.println("Deleted " + affected + " record(s) with ID " + idToDelete);
            } else {
                System.out.println("No record found for ID " + idToDelete);
            }
        } finally {
            HibernateUtil.shutdown();
        }
    }
}