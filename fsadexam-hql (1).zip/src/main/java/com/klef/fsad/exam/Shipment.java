package com.klef.fsad.exam;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "shipment")
public class Shipment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(nullable = false)
    private LocalDate date; // Shipment date

    @Column(nullable = false, length = 20)
    private String status; // e.g., CREATED, DISPATCHED, DELIVERED

    @Column(length = 255)
    private String description;

    @Column(name = "tracking_number", length = 50)
    private String trackingNumber;

    // --- Getters & Setters ---
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getTrackingNumber() { return trackingNumber; }
    public void setTrackingNumber(String trackingNumber) { this.trackingNumber = trackingNumber; }

    @Override
    public String toString() {
        return "Shipment{" +
                "id=" + id +
                ", name='" + name + ''' +
                ", date=" + date +
                ", status='" + status + ''' +
                ", description='" + description + ''' +
                ", trackingNumber='" + trackingNumber + ''' +
                '}';
    }
}